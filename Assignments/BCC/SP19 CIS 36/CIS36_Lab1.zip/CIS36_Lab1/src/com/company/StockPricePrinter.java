package com.company;

public class StockPricePrinter extends StockCustomer implements StockObserver {

    private int previousprice;


    @Override
    public void pricedChanged(PriceChangeEvent x) {

    }

    @Override
    public void run() {

    }
}
