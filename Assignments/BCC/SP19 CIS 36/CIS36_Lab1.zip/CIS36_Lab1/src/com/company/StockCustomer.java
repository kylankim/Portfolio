package com.company;

public class StockCustomer {

    private int currentPrice;
    private int step;

}
