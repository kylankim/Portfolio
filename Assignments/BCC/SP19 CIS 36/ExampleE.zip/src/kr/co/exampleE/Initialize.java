package kr.co.exampleE;

public @interface Initialize {

}
