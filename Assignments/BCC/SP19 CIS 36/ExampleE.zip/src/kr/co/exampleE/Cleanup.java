package kr.co.exampleE;

public @interface Cleanup {

}
