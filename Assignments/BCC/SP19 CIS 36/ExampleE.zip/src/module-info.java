/**
 * 
 */
/**
 * @author yooji
 *
 */
module ExampleE {
}