/**
 * 
 */
/**
 * @author yooji
 *
 */
module ExampleC {
}