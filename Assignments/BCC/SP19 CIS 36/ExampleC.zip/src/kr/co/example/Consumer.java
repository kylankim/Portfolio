package kr.co.example;

@FunctionalInterface
public interface Consumer<T> {
	void accept(T t);
}
