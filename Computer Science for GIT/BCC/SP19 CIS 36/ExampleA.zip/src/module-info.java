/**
 * 
 */
/**
 * @author yooji
 *
 */
module Example {
}