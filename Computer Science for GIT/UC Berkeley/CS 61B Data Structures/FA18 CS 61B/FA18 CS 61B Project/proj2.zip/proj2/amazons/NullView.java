package amazons;

/** A View that does nothing.
 *  @author P. N. Hilfinger
 */
class NullView implements View {

    @Override
    public void update(Board board) {
    }
}
