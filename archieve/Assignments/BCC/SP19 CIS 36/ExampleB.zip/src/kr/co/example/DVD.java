package kr.co.example;

public class DVD extends BorrowableItem{

}
