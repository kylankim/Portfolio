package kr.co.example;

import java.util.Date;

public class Book extends BorrowableItem{
	
}
