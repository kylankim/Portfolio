package kr.co.example;
import java.util.Date;

public interface Borrowable {
	void setBorrowerID(String s); 
	void setBorrowDate(Date d); 
	void setReturnDate(Date d); 
} 

