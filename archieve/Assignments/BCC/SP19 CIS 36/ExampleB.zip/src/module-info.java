
module ExampleB {
}