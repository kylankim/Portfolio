/**
 * 
 */
/**
 * @author yooji
 *
 */
module ExampleD {
}