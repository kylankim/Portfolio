//package signpost;
//
//public class note {
//    **
//            * Returns true iff this square may be connected to square S1, that is:
//            * + S1 is in the correct direction from this square.
//* + S1 does not have a current predecessor, this square does not
//* have a current successor, S1 is not the first cell in sequence,
//            * and this square is not the last.
//* + If S1 and this square both have sequence numbers, then
//* this square's is sequenceNum() == S1.sequenceNum() - 1.
//            * + If neither S1 nor this square have sequence numbers, then
//* they are not part of the same connected sequence.
//*/
//    boolean connectable(Sq s1) {
//        if ((dirOf(this.x, this.y, s1.x, s1.y) == this._dir) && (s1.predecessor() == null)
//                && (this.successor() == null) && (s1.sequenceNum() != 1)
//                && (this.sequenceNum() != (_width * _height))) { // 1 , 2
//            if (s1.sequenceNum() != 0 && this.sequenceNum() != 0) {
//                return (s1.sequenceNum() - 1 == this.sequenceNum());
//            } else if (sequenceNum() == 0 && s1.sequenceNum() == 0) {
//                return this.head() != s1.head();
//            }
//            return true;
//        }
//        return false;
//    }
//
//    /**
//     * Connect this square to S1, if both are connectable; otherwise do
//     * nothing. Returns true iff this square and S1 were connectable.
//     * Assumes S1 is in the proper arrow direction from this square.
//     */
//    boolean connect(Sq s1) {
//        if (!connectable(s1)) {
//            return false;
//        }
//        _unconnected -= 1;
//        _successor = s1;
//        s1._predecessor = this; //1
//
//        if (this.sequenceNum() != 0) {
//            if (s1.sequenceNum() == 0) {
//                releaseGroup(s1.group()); //5
//                for (Sq tmp1 = s1; tmp1 != null; tmp1 = tmp1._successor) {
//                    tmp1.set_sequenceNum(tmp1.predecessor().sequenceNum()+1);
//                    tmp1._group = 0;
//                }
//            }
//        } else if (s1.sequenceNum() != 0) {
//            releaseGroup(group()); //5
//            for (Sq tmp2 = this; tmp2 != null; tmp2 = tmp2._predecessor) {
//                tmp2.set_sequenceNum(tmp2.successor().sequenceNum()-1);
//                tmp2._group = 0;
//            }
//        } else {
//            head()._group = joinGroups(s1.group(), group());
//        }
//        for (Sq tmp = s1; tmp != null; tmp = tmp._successor) {
//            tmp._head = head();
//        }
//        return true;
//
//        // FIXME: Connect this square to its successor:
//        //        + Set this square's _successor field and S1's
//        //          _predecessor field. 1
//        //        + If this square has a number, number all its successors
//        //          accordingly (if needed). 2
//        //        + If S1 is numbered, number this square and its
//        //          predecessors accordingly (if needed). 3
//        //        + Set the _head fields of this square's successors this
//        //          square's _head. 4
//        //        + If either of this square or S1 used to be unnumbered
//        //          and is now numbered, release its group of whichever
//        //          was unnumbered, so that it can be reused. 5
//        //        + If both this square and S1 are unnumbered, set the
//        //          group of this square's head to the result of joining
//        //          the two groups.
//    }
//
//
//// FIXME: If both this and next are now one-element groups,
////        release their former group and set both group
////        numbers to -1.
////        Otherwise, if either is now a one-element group, set
////        its group number to -1 without releasing the group
////        number.
////        Otherwise, the group has been split into two multi-
////        element groups.  Create a new group for next.
//// FIXME: If neither this nor any square in its group that
////        precedes it has a fixed sequence number, set all
////        their sequence numbers to 0 and create a new group
////        for them if this has a current predecessor (other
////        set group to -1).
//
//// FIXME: If neither next nor any square in its group that
////        follows it has a fixed sequence number, set all
////        their sequence numbers to 0 and create a new
////        group for them if next has a current successor
////        (otherwise set next's group to -1.)
//// FIXME: Set the _head of next and all squares in its group to
////        next.
//
//    /**
//     * Disconnect this square from its current successor, if any.
//     */
//    void disconnect() {
//        Sq next = _successor;
//        if (next == null) {
//            return;
//        }
//        _unconnected += 1;
//        boolean fixed_checker = false;
//
//        this._successor = next._predecessor = null;
//
//        if (predecessor() == null && next._successor == null) {
//            next._head = next;
//            if (this.hasFixedNum() && !next.hasFixedNum()) {
//                next._group = -1;
//                next._sequenceNum = 0;
//            } else if (next.hasFixedNum()) {
//                _sequenceNum = 0;
//                _group = -1;
//            } else {
//                releaseGroup(group());
//                next._group = _group = -1;
//            }
//        } else if (predecessor() == null) {
//            for (Sq a = next; a != null; a = a.successor()) {
//                if (a.hasFixedNum()) { //check whether next has fixed sequence num
//                    fixed_checker = true;
//                } a._head = next;  //assign head of next to group of next
//            } if (!hasFixedNum()) { // head same, sequence same, //only new group id for next group,
//                if (!fixed_checker) { // no sequence
//                    next._group = group();
//                } else { //fixed sequence in the next group
//                    _sequenceNum = 0;
//                }
//                _group = -1;
//            } else { // yes sequence for this
//                if (!fixed_checker) { // no sequence for next
//                    for (Sq a = next; a != null; a = a.successor()) {
//                        a._sequenceNum = 0;
//                    }
//                    next._group = newGroup();
//                }
//            }
//        } else if (next.successor() == null) {
//            next._head = next;
//            for (Sq a = this; a != null && !fixed_checker; a = a.predecessor()) {
//                fixed_checker = a.hasFixedNum();
//            }
//            if (next.hasFixedNum() && !fixed_checker) {// no sequence num.
//                for (Sq a = this; a != null; a = a.predecessor()) {
//                    a._sequenceNum = 0;
//                }
//                head()._group = newGroup();
//            } else {
//                if (fixed_checker) { //not in next but in this group
//                    next._sequenceNum = 0;
//                }
//                next._group = -1;
//            }
//        } else {  //needs to check the fixed sequence in the group of this.
//            //both maintains a group
//            for (Sq a = next; a != null; a = a.successor()) {
//                if (a.hasFixedNum()) { //check whether next has fixed sequence num
//                    fixed_checker = true;
//                } a._head = next;
//            } boolean tmp_checker = false;
//            for (Sq b = this; b!= null && !tmp_checker; b = b.predecessor()) {
//                tmp_checker = b.hasFixedNum();
//            } if (!fixed_checker) {
//                if (tmp_checker) {
//                    for (Sq a = next; a != null; a = a.successor()) {
//                        a._sequenceNum = 0;
//                    }
//                } next._group = newGroup();
//            } else if (!tmp_checker) {
//                for (Sq b = this; b!= null; b = b.predecessor()) {
//                    b._sequenceNum = 0;
//                } head()._group = newGroup();
//            }
//        }
//
//        /**
//         * Return the unique square in MODEL that can connect to unconnected
//         * square END, or null if there isn't such a unique square.
//         * This function does not handle the case in which END and one of its
//         * predecessors is numbered, except when the numbered predecessor is
//         * the only unconnected predecessor.  This is because findUniqueSuccessor
//         * already finds the other cases of numbered, unconnected cells.
//         */
//        static Sq findUniquePredecessor(Model model, Sq end) {
//            PlaceList A = new PlaceList();
//            PlaceList B = new PlaceList();
//            if (end == null || end.predecessors() == null || end.sequenceNum() == 1) {
//                return null;
//            }
//            for (Place a : end.predecessors()) {
//                if (model.get(a.x, a.y).connectable(end)) {
//                    A.add(a);
//                }
//            }
//            return model.get(A.get(0));
//        }

//        for (Place a : end.predecessors()) {
//            if (model.get(a).sequenceNum() != 0 || end.sequenceNum() != 0) {
//                B.add(a);
//            }
//            if (model.get(a).connectable(end) && model.get(a).group() == -1) {
//                A.add(a);
//            }
//        }
//        if (B.size() >= 2) {
//            return null;
//        } else if (A.size() == 1) {
//            return model.get(A.get(0));
//        }
//        return null;
//    }
//
//    }
//
//}
